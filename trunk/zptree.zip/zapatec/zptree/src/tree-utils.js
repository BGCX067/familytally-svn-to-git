/**
 * Utils class with some commonly used small methods
 */
Zapatec.Tree.Utils = {};

/**
 * @private
 * This method is used to convert HTML &lt;LI&gt; element into JSON structure for Zapatec.Tree.Node
 * @param [Object] liNode DOM node
 * @param [boolean] compatibility with Zapatec.Tree version less the 2.2
 * @return JSON array with data
 * @type Object
 */
Zapatec.Tree.Utils.convertLi2Json = function(liNode, compat){
	if(
		liNode == null || 
		liNode.nodeType != 1 ||
		liNode.nodeName.toLowerCase() != 'li'
	){
		return null;
	}

	var struct = {attributes: {}};
	var ul = null;
	var expandedIcon = null;
	var collapsedIcon = null;
	var fetchingIcon = null;
	var icon = null;
	var labelEl = document.createElement("span");
	var cNodes = [];
	
	for(var ii = 0;  ii < liNode.childNodes.length; ii++){
		cNodes.push(liNode.childNodes[ii]);
	}
	
	for(var ii = 0; ii < cNodes.length; ii++){
		var node = cNodes[ii];

		if(node.nodeType == 1){
			if(node.nodeName.toLowerCase() == 'img'){
				if(compat){
					if(icon == null){
						icon = node;
					}

					// if this is 2.0 compatible mode - take first two images as +- buttons
					if(expandedIcon == null){
						expandedIcon = node;
						Zapatec.Utils.addClass(expandedIcon, "expandedIcon");
						continue;
					} else if(collapsedIcon == null){
						collapsedIcon = node;
						Zapatec.Utils.addClass(collapsedIcon, "collapsedIcon");
						continue;
					}

					if(icon == node){
						continue;
					}
				} else {
					// if not compatible - search using classname
					if(/\belementIcon\b/.test(node.className)){
						icon = node;
						continue;
					} else if(/\bexpandedIcon\b/.test(node.className)){
						expandedIcon = node;
						continue;
					} else if(/\bcollapsedIcon\b/.test(node.className)){
						collapsedIcon = node;
						continue;
					} else if(/\bfetchingIcon\b/.test(node.className)){
						fetchingIcon = node;
						continue;
					}
				}
			}

			if(node.nodeName.toLowerCase() == 'ul'){
				ul = node;
				continue;
			}
		}

		labelEl.appendChild(node.cloneNode(true));
	}

	if(Zapatec.is_khtml){
		var allChildren = labelEl.all ? labelEl.all : labelEl.getElementsByTagName("*");
		
		for(var ii = 0; ii < allChildren.length; ii++){
			var child = allChildren[ii];

			for(var jj = 0; jj < child.attributes.length; jj++){
				var attr = child.attributes[jj];
				child.setAttribute(attr.nodeName, attr.nodeValue.replace(/"/g, "'"));
			}
		}
	}

	struct['label'] = labelEl.innerHTML;
	if(Zapatec.is_opera){
		// Opera bug: http://my.opera.com/community/forums/topic.dml?id=99268&t=1164901696&page=1
		// Opera do some strange things with quotes when getting innerHTML
		// So we need to replace all \" with single quotes '
		// this may cause some errors in javascript :(
		struct['label'] = struct['label'].replace(/\\"/g, "'"); 
	}

	struct['isSelected'] = liNode.className.match(/\bselected\b/) != null;
	struct['isExpanded'] = liNode.className.match(/\bexpanded\b/) != null;

	for(var ii = 0; ii < liNode.attributes.length; ii++){
		var attr = liNode.attributes[ii];
		struct['attributes'][attr.nodeName.toLowerCase()] = attr.nodeValue;
	}

	// if node has <UL> element inside - append its <LI>s as child nodes.
	if(ul == null){
		if(icon){
			Zapatec.Utils.addClass(icon, "elementIcon");
			var tmpIcon = document.createElement("SPAN");
			tmpIcon.appendChild(icon);
			struct['elementIcon'] = tmpIcon.innerHTML;
		}
	} else {
		if(expandedIcon){
			var tmpIcon = document.createElement("SPAN");
			tmpIcon.appendChild(expandedIcon);
			struct['expandedIcon'] = tmpIcon.innerHTML;
		}
	    
		if(collapsedIcon){
			var tmpIcon = document.createElement("SPAN");
			tmpIcon.appendChild(collapsedIcon);
			struct['collapsedIcon'] = tmpIcon.innerHTML;
		}
	    
		if(fetchingIcon){
			var tmpIcon = document.createElement("SPAN");
			tmpIcon.appendChild(fetchingIcon);
			struct['fetchingIcon'] = tmpIcon.innerHTML;
		}

		struct['children'] = [];

		for(var ii = 0; ii < ul.childNodes.length; ii++){
			var tmp = Zapatec.Tree.Utils.convertLi2Json(ul.childNodes[ii], compat);
			
			if(tmp != null){
				struct['children'].push(tmp);
			}
		}
	}

	return struct;
};

/**
 * @private
 * This function transforms XML node to DOM node.
 * @param [Object] XML node
 * @return DOM node
 * @type Object
 */
Zapatec.Tree.Utils.xml2dom = function(node){
	if(node.nodeType == 3){
		return document.createTextNode(node.nodeValue);
	}

	if(node.nodeType != 1){
		return null;
	}
	
	var el = Zapatec.Utils.createElement(node.nodeName);

	for (var ii = 0; ii < node.attributes.length; ii++){
		var attr = node.attributes[ii];
	
		if(attr.name.toLowerCase() == "class"){
			el.className = node.getAttribute(attr.name);
		} else {      
			el.setAttribute(attr.name, node.getAttribute(attr.name));
		}
	}

	if(node.hasChildNodes()){
		for(var ii = 0; ii < node.childNodes.length; ii++){
			var childNode = Zapatec.Tree.Utils.xml2dom(node.childNodes[ii]);
		
			if(childNode != null){
				el.appendChild(childNode);
			}
		}
	}

	return el;
};

/**
 * @private
 * This method is used to convert XML tree into JSON structure for Zapatec.Tree.Node
 * @param [Object] XML node
 * @return JSON array with data
 * @type Object
 */
Zapatec.Tree.Utils.convertXml2Json = function(itemNode){
	if(
		itemNode == null || 
		itemNode.nodeType != 1 ||
		itemNode.nodeName.toLowerCase() != 'item'
	){
		return null;
	}

	var struct = {content: null, attributes: {}};
	var list = null;

	var labelEl = document.createElement("span");
	
	for(var ii = itemNode.childNodes.length - 1; ii >= 0 ; ii--){
		var node = itemNode.childNodes[ii];

		if(node.nodeType != 1){
			continue;
		}

		if(node.nodeName.toLowerCase() == "attribute" && node.hasAttribute("name")){
			struct.attributes[node.getAttribute("name")] = node.textContent;
			continue;
		}

		if(node.nodeName.toLowerCase() == 'list'){
			list = node;
			continue;
		}

		if(node.nodeName.toLowerCase() == 'label'){
			for(var jj = 0; jj < node.childNodes.length; jj++){
				labelEl.insertBefore(Zapatec.Tree.Utils.xml2dom(node.childNodes[jj]), labelEl.firstChild);
			}
		
			continue;
		}
	}

	struct['label'] = labelEl.innerHTML;
	struct['isSelected'] = itemNode.getAttribute("isSelected") == "true";
	struct['isExpanded'] = itemNode.getAttribute("isExpanded") == "true";

	struct['source'] = itemNode.getAttribute("source");
	struct['sourceType'] = itemNode.getAttribute("sourceType");

	if(list == null){
		struct['elementIcon'] = itemNode.getAttribute("elementIcon"); 
	} else {
		struct['collapsedIcon'] = itemNode.getAttribute("collapsedIcon"); 
		struct['expandedIcon'] = itemNode.getAttribute("expandedIcon"); 
		struct['fetchingIcon'] = itemNode.getAttribute("fetchingIcon"); 

		struct['children'] = [];

		for(var ii = 0; ii < list.childNodes.length; ii++){
			var tmp = Zapatec.Tree.Utils.convertXml2Json(list.childNodes[ii]);
			
			if(tmp != null){
				struct['children'].push(tmp);
			}
		}
	}

	return struct;
};

Zapatec.Tree.Utils.getNodeIndex = function(node){
	if(!node || !node.config || !node.config.parentNode || !node.config.parentNode.children){
		return null;
	}
	
	for(var ii = 0; ii < node.config.parentNode.children.length; ii++){
		if(node.config.parentNode.children[ii] == node){
			return ii;
		}
	}
};
