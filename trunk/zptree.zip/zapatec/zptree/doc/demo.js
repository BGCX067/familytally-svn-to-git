	zpDemo.zpdefDemo = "basic.html";
	zpDemo.zpdemos = {
		
			"basic.html": {title: "Basic features", url: "../demo/basic.html", css: ["basic","default","image","lines"]},
			"load_data.html": {title: "Dynamically load data from server", url: "../demo/load_data.html", css: ["default"]},
			"large.html": {title: "Very large tree", url: "../demo/large.html", css: ["default"]},
			"html.html": {title: "Tree with HTML", url: "../demo/html.html", css: ["default"]},
			"savestate.html": {title: "Save State", url: "../demo/savestate.html", css: ["lightgreen","purple","wood","zapatec"]},
			"themes.html": {title: "Other themes", url: "../demo/themes.html", css: ["default"]},
			"compact.html": {title: "Compact tree", url: "../demo/compact.html", css: ["default","empty"]},
			"icons.html": {title: "Adding icons", url: "../demo/icons.html", css: ["default"]},
			"selections.html": {title: "Customize nodes selection", url: "../demo/selections.html", css: ["default"]},
			"keyboard_navigation.html": {title: "Keyboard navigation", url: "../demo/keyboard_navigation.html", css: ["default"]},
			"editable.html": {title: "Editable tree", url: "../demo/editable.html", css: ["default"]}
	};
	zpDemo.zpdemogroups = {
	
	};

	// Name of this widget
	zpDemo.strWidget='Tree'
	// path to css for this widget
	zpDemo.cssPath='../themes'

